import { useMemo, useState } from 'react';
import Sidebar from "./components/Slidebar";
import Navbar from "./components/Navbar";
import Masonry from "./components/Masonry";
import ProfileModal from "./components/ProfileModal";
import CategoryFilters from "./components/CategoryFilters";

interface Item {
  id: string;
  img: string;
  url: string;
  height: number;
  title?: string;
  category?: string;
  year?: string;
  rating?: number;
  synopsis?: string;
}

export default function Home() {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [activeView, setActiveView] = useState<'forYou' | 'friends' | 'explore'>('forYou');
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);

  // Dados de exemplo (substitua por dados do BD/backend)
  const sampleItems: Item[] = useMemo(() => [
    {
      id: '1',
      img: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400',
      url: '#',
      height: 800,
      title: 'The Dark Knight',
      category: 'Ação',
      year: '2008',
      rating: 9,
      synopsis: 'Batman tem que manter o equilíbrio entre o heroísmo e a vingança...'
    },
    // ... (todos os outros itens do código fornecido)
  ], []);

  const [userStats] = useState({
    likedMovies: 42,
    favoriteMovies: 15,
    watchedMovies: 128
  });

  const handleSettingsClick = () => {
    console.log("Settings clicked!");
  };

  const handleProfileClick = () => {
    setIsProfileOpen(true);
  };

  const handleForYouClick = () => {
    console.log("For You clicked!");
    setActiveView('forYou');
    setSelectedCategory(undefined); // Reset categoria ao mudar view
  };

  const handleFriendsClick = () => {
    console.log("Friends suggestions clicked!");
    setActiveView('friends');
    setSelectedCategory(undefined); // Reset categoria
  };

  const handleExploreClick = () => {
    console.log("Explore clicked!");
    setActiveView('explore');
  };

  const handleSearch = (query: string) => {
    console.log("Searching for:", query);
  };

  // Filtrar itens apenas se em 'explore' e com categoria selecionada
  const itemsToDisplay = activeView === 'explore'
    ? sampleItems.filter(item => !selectedCategory || item.category === selectedCategory)
    : sampleItems;

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        minHeight: "100vh",
        background: "linear-gradient(135deg, #fffff0 0%, #fff8dc 100%)",
      }}
    >
      <Navbar 
        onHomeClick={handleForYouClick}
        onFriendsClick={handleFriendsClick}
        onSearch={handleSearch}
      />

      <Sidebar 
        onSettingsClick={handleSettingsClick}
        onProfileClick={handleProfileClick}
        onExploreClick={handleExploreClick}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        likedMovies={userStats.likedMovies}
        favoriteMovies={userStats.favoriteMovies}
        watchedMovies={userStats.watchedMovies}
      />

      <main
        style={{
          marginLeft: "80px",
          paddingTop: "100px",
          paddingLeft: "3rem",
          paddingRight: "3rem",
          paddingBottom: "3rem",
          minHeight: "100vh",
          backgroundColor: "transparent"
        }}
      >
        <div style={{ maxWidth: "100%", margin: "0 auto", maxHeight: "100%" }}>
          {/* Seção de Título e Filtros */}
          <div style={{ marginBottom: "2rem", paddingLeft: "1rem" }}>
            <h2 style={{
              fontSize: "1.5rem",
              fontWeight: "600",
              color: "#1a1a1a",
              margin: 0
            }}>
              {activeView === 'forYou' ? 'Para Você' : activeView === 'friends' ? 'Sugestões de Amigos' : 'Explorar'}
            </h2>
            <p style={{
              fontSize: "0.95rem",
              color: "#666",
              margin: "0.5rem 0 0 0"
            }}>
              {activeView === 'forYou' 
                ? 'Filmes recomendados com base nos seus gostos' 
                : activeView === 'friends'
                ? 'Veja o que seus amigos estão assistindo'
                : 'Filtre por categorias e explore filmes'}
            </p>

            {/* Filtros de categorias */}
            {activeView === 'explore' && (
              <CategoryFilters 
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
              />
            )}
          </div>

          {/* Galeria Masonry */}
          <Masonry />
        </div>
      </main>
    </div>
  );
}