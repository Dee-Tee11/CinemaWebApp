// components/ProfileModal.tsx
import React from 'react';
import { X, Heart, Star, Eye, User } from 'lucide-react';
import { useUser } from '@clerk/clerk-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  likedMovies?: number;
  favoriteMovies?: number;
  watchedMovies?: number;
}

export default function ProfileModal({ 
  isOpen, 
  onClose,
  likedMovies = 0,
  favoriteMovies = 0,
  watchedMovies = 0
}: ProfileModalProps) {
  const { user } = useUser();

  if (!isOpen) return null;

  const userName = user?.fullName || user?.username || 'Usuário';
  const userEmail = user?.primaryEmailAddress?.emailAddress || '';

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed',
          inset: 0,
          background: 'rgba(0, 0, 0, 0.6)',
          backdropFilter: 'blur(4px)',
          zIndex: 9998,
          animation: 'fadeIn 0.3s ease-out'
        }}
      />

      {/* Modal */}
      <div
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '90%',
          maxWidth: '500px',
          background: 'linear-gradient(135deg, #fff9f0 0%, #ffe8cc 100%)',
          borderRadius: '24px',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
          border: '2px solid rgba(153, 27, 27, 0.2)',
          zIndex: 9999,
          animation: 'slideUp 0.3s ease-out',
          overflow: 'hidden'
        }}
      >
        {/* Header */}
        <div style={{
          background: '#991b1b',
          padding: '1.5rem',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderBottom: '2px solid rgba(255, 255, 255, 0.1)'
        }}>
          <h2 style={{
            color: 'white',
            fontSize: '1.5rem',
            fontWeight: '700',
            margin: 0
          }}>
            Meu Perfil
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              borderRadius: '50%',
              width: '36px',
              height: '36px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              color: 'white',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
              e.currentTarget.style.transform = 'rotate(90deg)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.1)';
              e.currentTarget.style.transform = 'rotate(0deg)';
            }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '2rem' }}>
          {/* User Info */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            marginBottom: '2rem'
          }}>
            <div style={{
              width: '100px',
              height: '100px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #991b1b 0%, #dc2626 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: '1rem',
              boxShadow: '0 4px 20px rgba(153, 27, 27, 0.3)',
              border: '3px solid white'
            }}>
              {user?.imageUrl ? (
                <img 
                  src={user.imageUrl} 
                  alt={userName}
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: '50%',
                    objectFit: 'cover'
                  }}
                />
              ) : (
                <User size={50} color="white" />
              )}
            </div>
            <h3 style={{
              fontSize: '1.5rem',
              fontWeight: '700',
              color: '#991b1b',
              margin: '0 0 0.5rem 0'
            }}>
              {userName}
            </h3>
            {userEmail && (
              <p style={{
                fontSize: '0.9rem',
                color: '#666',
                margin: 0
              }}>
                {userEmail}
              </p>
            )}
          </div>

          {/* Stats Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '1rem'
          }}>
            {/* Liked Movies */}
            <div style={{
              background: 'white',
              borderRadius: '16px',
              padding: '1.5rem 1rem',
              textAlign: 'center',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              border: '1px solid rgba(153, 27, 27, 0.1)',
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: 'rgba(239, 68, 68, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 0.75rem'
              }}>
                <Heart size={24} color="#ef4444" fill="#ef4444" />
              </div>
              <div style={{
                fontSize: '1.75rem',
                fontWeight: '700',
                color: '#991b1b',
                marginBottom: '0.25rem'
              }}>
                {likedMovies}
              </div>
              <div style={{
                fontSize: '0.85rem',
                color: '#666',
                fontWeight: '500'
              }}>
                Gostei
              </div>
            </div>

            {/* Favorite Movies */}
            <div style={{
              background: 'white',
              borderRadius: '16px',
              padding: '1.5rem 1rem',
              textAlign: 'center',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              border: '1px solid rgba(153, 27, 27, 0.1)',
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: 'rgba(234, 179, 8, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 0.75rem'
              }}>
                <Star size={24} color="#eab308" fill="#eab308" />
              </div>
              <div style={{
                fontSize: '1.75rem',
                fontWeight: '700',
                color: '#991b1b',
                marginBottom: '0.25rem'
              }}>
                {favoriteMovies}
              </div>
              <div style={{
                fontSize: '0.85rem',
                color: '#666',
                fontWeight: '500'
              }}>
                Favoritos
              </div>
            </div>

            {/* Watched Movies */}
            <div style={{
              background: 'white',
              borderRadius: '16px',
              padding: '1.5rem 1rem',
              textAlign: 'center',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
              border: '1px solid rgba(153, 27, 27, 0.1)',
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-4px)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
            >
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: 'rgba(59, 130, 246, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 0.75rem'
              }}>
                <Eye size={24} color="#3b82f6" />
              </div>
              <div style={{
                fontSize: '1.75rem',
                fontWeight: '700',
                color: '#991b1b',
                marginBottom: '0.25rem'
              }}>
                {watchedMovies}
              </div>
              <div style={{
                fontSize: '0.85rem',
                color: '#666',
                fontWeight: '500'
              }}>
                Vistos
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translate(-50%, -40%);
          }
          to {
            opacity: 1;
            transform: translate(-50%, -50%);
          }
        }

        @media (max-width: 768px) {
          div[style*="gridTemplateColumns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </>
  );
}