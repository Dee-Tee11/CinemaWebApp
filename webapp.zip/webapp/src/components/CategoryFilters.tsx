
import React from 'react';

interface CategoryFiltersProps {
  selectedCategory: string | undefined;
  setSelectedCategory: (category: string | undefined) => void;
}

const categories = ['Todas', 'Ação', 'Ficção Científica', 'Aventura', 'Crime', 'Drama'];

export default function CategoryFilters({ selectedCategory, setSelectedCategory }: CategoryFiltersProps) {
  return (
    <div style={{ 
      display: 'flex', 
      gap: '1rem', 
      marginTop: '1.5rem', 
      flexWrap: 'wrap',
      alignItems: 'center'
    }}>
      {categories.map((category) => (
        <button
          key={category}
          onClick={() => setSelectedCategory(category === 'Todas' ? undefined : category)}
          style={{
            padding: '0.5rem 1rem',
            borderRadius: '20px',
            backgroundColor: selectedCategory === category || (category === 'Todas' && !selectedCategory) 
              ? '#991b1b' 
              : 'rgba(153, 27, 27, 0.2)',
            color: selectedCategory === category || (category === 'Todas' && !selectedCategory) 
              ? 'white' 
              : '#1a1a1a',
            border: 'none',
            cursor: 'pointer',
            transition: 'all 0.3s',
            fontSize: '0.875rem',
            fontWeight: '500'
          }}
          onMouseEnter={(e) => {
            if (selectedCategory !== category && !(category === 'Todas' && !selectedCategory)) {
              e.currentTarget.style.backgroundColor = 'rgba(153, 27, 27, 0.4)';
            } else {
              e.currentTarget.style.backgroundColor = '#7f1d1d';
            }
          }}
          onMouseLeave={(e) => {
            if (selectedCategory !== category && !(category === 'Todas' && !selectedCategory)) {
              e.currentTarget.style.backgroundColor = 'rgba(153, 27, 27, 0.2)';
            } else {
              e.currentTarget.style.backgroundColor = '#991b1b';
            }
          }}
        >
          {category}
        </button>
      ))}
    </div>
  );
}